# import fitz  # PyMuPDF
# import json
# from pathlib import Path
# from datetime import datetime

# def extract_summary(collection_path):
#     input_path = collection_path / "challenge1b_input.json"
#     pdf_dir = collection_path / "PDFs"
#     output_path = collection_path / "challenge1b_output.json"

#     with open(input_path, 'r', encoding='utf-8') as f:
#         data = json.load(f)

#     persona = data["persona"]["role"]
#     task = data["job_to_be_done"]["task"]
#     documents = data["documents"]

#     results = []

#     for doc in documents:
#         pdf_file = pdf_dir / doc["filename"]
#         if not pdf_file.exists():
#             continue

#         text_chunks = []
#         with fitz.open(pdf_file) as pdf:
#             for page_num, page in enumerate(pdf, 1):
#                 text = page.get_text()
#                 if text.strip():
#                     text_chunks.append((page_num, text.strip()))

#         # Simple relevance scoring: count overlapping words
#         def relevance(chunk):
#             chunk_text = chunk[1].lower()
#             task_words = set(task.lower().split())
#             return sum(1 for w in task_words if w in chunk_text)

#         scored_chunks = [(page_num, chunk_text, relevance((page_num, chunk_text))) for page_num, chunk_text in text_chunks]
#         scored_chunks.sort(key=lambda x: x[2], reverse=True)
#         best_chunk = scored_chunks[0] if scored_chunks else (None, "", 0)

#         results.append({
#             "filename": doc["filename"],
#             "title": doc["title"],
#             "page_number": best_chunk[0],
#             "summary": best_chunk[1],
#             "score": best_chunk[2]
#         })

#     output = {
#         "metadata": {
#             "documents": documents,
#             "persona": persona,
#             "job_to_be_done": task,
#             "timestamp": datetime.now().isoformat()
#         },
#         "results": results
#     }

#     with open(output_path, "w", encoding='utf-8') as f:
#         json.dump(output, f, indent=2)

#     print(f"✅ Done for: {collection_path.name}")

# # Run for each collection
# base_dir = Path("Challenge_1b")
# for folder in base_dir.iterdir():
#     if folder.is_dir():
#         extract_summary(folder)

#---------------------------------------------------------------------------------------------------------

# import fitz  # PyMuPDF
# import json
# from pathlib import Path
# from datetime import datetime
# import re
# from collections import defaultdict

# def extract_section_title(text):
#     """Extract section title from text - looks for lines that appear to be headers"""
#     lines = text.split('\n')
#     for line in lines[:5]:  # Check first 5 lines
#         line = line.strip()
#         if line and len(line) < 100:  # Likely a title if short and not empty
#             # Remove common formatting artifacts
#             line = re.sub(r'^[•\-\*\s]+', '', line)
#             if line and not line.lower().startswith(('page', 'chapter')):
#                 return line
#     return "Introduction"  # Default fallback

# def calculate_importance_score(text, task, persona):
#     """Calculate importance score based on task and persona relevance"""
#     text_lower = text.lower()
#     task_lower = task.lower()
    
#     # High priority keywords for college trip planning
#     high_priority = ['group', 'friends', 'college', 'budget', 'activities', 'nightlife', 
#                     'entertainment', 'beach', 'young', 'adventure', 'party', 'fun']
    
#     # Medium priority keywords
#     medium_priority = ['restaurant', 'food', 'travel', 'trip', 'plan', 'guide', 
#                       'things to do', 'attractions', 'tips']
    
#     # Task-specific keywords
#     task_keywords = set(task_lower.split())
    
#     score = 0
    
#     # Score based on keyword presence
#     for keyword in high_priority:
#         if keyword in text_lower:
#             score += 3
    
#     for keyword in medium_priority:
#         if keyword in text_lower:
#             score += 2
    
#     # Score based on task keyword overlap
#     text_words = set(text_lower.split())
#     overlap = len(task_keywords.intersection(text_words))
#     score += overlap * 2
    
#     # Bonus for comprehensive guides or main sections
#     if any(term in text_lower for term in ['comprehensive guide', 'ultimate guide', 'introduction']):
#         score += 5
    
#     return score

# def extract_refined_text(text, max_length=800):
#     """Extract and refine text to be more concise and relevant"""
#     # Remove excessive whitespace and clean up
#     text = re.sub(r'\n+', ' ', text)
#     text = re.sub(r'\s+', ' ', text)
#     text = text.strip()
    
#     # If text is too long, try to extract key paragraphs
#     if len(text) > max_length:
#         sentences = text.split('. ')
#         # Keep sentences that seem most informative
#         key_sentences = []
#         current_length = 0
        
#         for sentence in sentences:
#             if current_length + len(sentence) < max_length:
#                 key_sentences.append(sentence)
#                 current_length += len(sentence)
#             else:
#                 break
        
#         text = '. '.join(key_sentences)
#         if not text.endswith('.'):
#             text += '.'
    
#     return text

# def extract_summary(collection_path):
#     input_path = collection_path / "challenge1b_input.json"
#     pdf_dir = collection_path / "PDFs"
#     output_path = collection_path / "challenge1b_output.json"

#     with open(input_path, 'r', encoding='utf-8') as f:
#         data = json.load(f)

#     persona = data["persona"]["role"]
#     task = data["job_to_be_done"]["task"]
#     documents = data["documents"]

#     extracted_sections = []
#     subsection_analysis = []
#     all_sections = []

#     # Process each document
#     for doc in documents:
#         pdf_file = pdf_dir / doc["filename"]
#         if not pdf_file.exists():
#             continue

#         with fitz.open(pdf_file) as pdf:
#             for page_num, page in enumerate(pdf, 1):
#                 text = page.get_text()
#                 if text.strip() and len(text.strip()) > 100:  # Only consider substantial pages
#                     section_title = extract_section_title(text)
#                     importance_score = calculate_importance_score(text, task, persona)
                    
#                     all_sections.append({
#                         "document": doc["filename"],
#                         "section_title": section_title,
#                         "page_number": page_num,
#                         "text": text.strip(),
#                         "importance_score": importance_score
#                     })

#     # Sort by importance score and select top sections
#     all_sections.sort(key=lambda x: x["importance_score"], reverse=True)
    
#     # Select top 5 sections for extracted_sections
#     selected_sections = all_sections[:5]
    
#     for i, section in enumerate(selected_sections, 1):
#         extracted_sections.append({
#             "document": section["document"],
#             "section_title": section["section_title"],
#             "importance_rank": i,
#             "page_number": section["page_number"]
#         })

#     # Create subsection analysis for selected sections
#     # Group sections by document to avoid too many from same document
#     doc_sections = defaultdict(list)
#     for section in selected_sections:
#         doc_sections[section["document"]].append(section)
    
#     # Select diverse sections for subsection analysis
#     for doc_name, sections in doc_sections.items():
#         # Take up to 2 sections per document for subsection analysis
#         for section in sections[:2]:
#             refined_text = extract_refined_text(section["text"])
#             subsection_analysis.append({
#                 "document": doc_name,
#                 "refined_text": refined_text,
#                 "page_number": section["page_number"]
#             })

#     # Prepare output
#     output = {
#         "metadata": {
#             "input_documents": [doc["filename"] for doc in documents],
#             "persona": persona,
#             "job_to_be_done": task,
#             "processing_timestamp": datetime.now().isoformat()
#         },
#         "extracted_sections": extracted_sections,
#         "subsection_analysis": subsection_analysis
#     }

#     with open(output_path, "w", encoding='utf-8') as f:
#         json.dump(output, f, indent=2)

#     print(f"✅ Done for: {collection_path.name}")

# # Run for each collection
# base_dir = Path("Challenge_1b")
# for folder in base_dir.iterdir():
#     if folder.is_dir():
#         extract_summary(folder)

# ----------------------------------------------------------------------------------------------------------------

import fitz  # PyMuPDF
import json
from pathlib import Path
from datetime import datetime
import re
from collections import defaultdict

def clean_unicode_text(text):
    """Clean Unicode characters and formatting artifacts from text"""
    # Dictionary of common Unicode replacements
    unicode_replacements = {
        '\u2022': '• ',  # Bullet point
        '\u2013': '- ',  # En dash
        '\u2014': '- ',  # Em dash
        '\u2018': "'",   # Left single quote
        '\u2019': "'",   # Right single quote
        '\u201c': '"',   # Left double quote
        '\u201d': '"',   # Right double quote
        '\u00a0': ' ',   # Non-breaking space
        '\ufb00': 'ff',  # ff ligature
        '\ufb01': 'fi',  # fi ligature
        '\ufb02': 'fl',  # fl ligature
        '\ufb03': 'ffi', # ffi ligature
        '\ufb04': 'ffl', # ffl ligature
        '\u00e9': 'e',   # é
        '\u00e8': 'e',   # è
        '\u00ea': 'e',   # ê
        '\u00e0': 'a',   # à
        '\u00e7': 'c',   # ç
    }
    
    # Replace Unicode characters
    for unicode_char, replacement in unicode_replacements.items():
        text = text.replace(unicode_char, replacement)
    
    # Remove other problematic Unicode characters
    text = re.sub(r'[\u2000-\u206F\u2E00-\u2E7F\u3000-\u303F]', ' ', text)
    
    return text

def extract_section_title(text):
    """Extract section title from text - looks for lines that appear to be headers"""
    # Clean the text first
    text = clean_unicode_text(text)
    
    lines = text.split('\n')
    for line in lines[:5]:  # Check first 5 lines
        line = line.strip()
        if line and len(line) < 100:  # Likely a title if short and not empty
            # Remove common formatting artifacts
            line = re.sub(r'^[•\-\*\s]+', '', line)
            if line and not line.lower().startswith(('page', 'chapter')):
                return line
    return "Introduction"  # Default fallback

def calculate_importance_score(text, task, persona):
    """Calculate importance score based on task and persona relevance"""
    # Clean text first
    text = clean_unicode_text(text)
    text_lower = text.lower()
    task_lower = task.lower()
    
    # High priority keywords for college trip planning
    high_priority = ['group', 'friends', 'college', 'budget', 'activities', 'nightlife', 
                    'entertainment', 'beach', 'young', 'adventure', 'party', 'fun']
    
    # Medium priority keywords
    medium_priority = ['restaurant', 'food', 'travel', 'trip', 'plan', 'guide', 
                      'things to do', 'attractions', 'tips']
    
    # Task-specific keywords
    task_keywords = set(task_lower.split())
    
    score = 0
    
    # Score based on keyword presence
    for keyword in high_priority:
        if keyword in text_lower:
            score += 3
    
    for keyword in medium_priority:
        if keyword in text_lower:
            score += 2
    
    # Score based on task keyword overlap
    text_words = set(text_lower.split())
    overlap = len(task_keywords.intersection(text_words))
    score += overlap * 2
    
    # Bonus for comprehensive guides or main sections
    if any(term in text_lower for term in ['comprehensive guide', 'ultimate guide', 'introduction']):
        score += 5
    
    return score

def extract_refined_text(text, max_length=800):
    """Extract and refine text to be more concise and relevant"""
    # Clean Unicode characters first
    text = clean_unicode_text(text)
    
    # Remove excessive whitespace and clean up
    text = re.sub(r'\n+', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    
    # If text is too long, try to extract key paragraphs
    if len(text) > max_length:
        sentences = text.split('. ')
        # Keep sentences that seem most informative
        key_sentences = []
        current_length = 0
        
        for sentence in sentences:
            if current_length + len(sentence) < max_length:
                key_sentences.append(sentence)
                current_length += len(sentence)
            else:
                break
        
        text = '. '.join(key_sentences)
        if not text.endswith('.'):
            text += '.'
    
    return text

def extract_summary(collection_path):
    input_path = collection_path / "challenge1b_input.json"
    pdf_dir = collection_path / "PDFs"
    output_path = collection_path / "challenge1b_output.json"

    with open(input_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    persona = data["persona"]["role"]
    task = data["job_to_be_done"]["task"]
    documents = data["documents"]

    extracted_sections = []
    subsection_analysis = []
    all_sections = []

    # Process each document
    for doc in documents:
        pdf_file = pdf_dir / doc["filename"]
        if not pdf_file.exists():
            continue

        with fitz.open(pdf_file) as pdf:
            for page_num, page in enumerate(pdf, 1):
                text = page.get_text()
                if text.strip() and len(text.strip()) > 100:  # Only consider substantial pages
                    # Clean the text immediately after extraction
                    cleaned_text = clean_unicode_text(text.strip())
                    
                    section_title = extract_section_title(cleaned_text)
                    importance_score = calculate_importance_score(cleaned_text, task, persona)
                    
                    all_sections.append({
                        "document": doc["filename"],
                        "section_title": section_title,
                        "page_number": page_num,
                        "text": cleaned_text,
                        "importance_score": importance_score
                    })

    # Sort by importance score and select top sections
    all_sections.sort(key=lambda x: x["importance_score"], reverse=True)
    
    # Select top 5 sections for extracted_sections
    selected_sections = all_sections[:5]
    
    for i, section in enumerate(selected_sections, 1):
        extracted_sections.append({
            "document": section["document"],
            "section_title": section["section_title"],
            "importance_rank": i,
            "page_number": section["page_number"]
        })

    # Create subsection analysis for selected sections
    # Group sections by document to avoid too many from same document
    doc_sections = defaultdict(list)
    for section in selected_sections:
        doc_sections[section["document"]].append(section)
    
    # Select diverse sections for subsection analysis
    for doc_name, sections in doc_sections.items():
        # Take up to 2 sections per document for subsection analysis
        for section in sections[:2]:
            refined_text = extract_refined_text(section["text"])
            subsection_analysis.append({
                "document": doc_name,
                "refined_text": refined_text,
                "page_number": section["page_number"]
            })

    # Prepare output
    output = {
        "metadata": {
            "input_documents": [doc["filename"] for doc in documents],
            "persona": persona,
            "job_to_be_done": task,
            "processing_timestamp": datetime.now().isoformat()
        },
        "extracted_sections": extracted_sections,
        "subsection_analysis": subsection_analysis
    }

    with open(output_path, "w", encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"✅ Done for: {collection_path.name}")

# Run for each collection
base_dir = Path("Challenge_1b")
for folder in base_dir.iterdir():
    if folder.is_dir():
        extract_summary(folder)
