# Challenge 1B - Persona PDF Analyzer

## How to Use

1. 🗂️ Place your PDFs and `challenge1b_input.json` inside each `Collection` folder  
2. 🛠️ Build Docker image:
   ```bash
   docker build -t challenge1b-lite .
   ```
3. 🚀 Run analysis:
   ```bash
   docker run --rm -v "${PWD}/Challenge_1b:/app/Challenge_1b" challenge1b-lite
   ```

💡 If using Windows, use this in PowerShell:

```powershell
$vol = (Get-Location).Path + "\Challenge_1b"
docker run --rm -v "${vol}:/app/Challenge_1b" challenge1b-lite
```

---

## 🛠️ HOW TO SET IT UP

### Step 1: Create this folder structure
Put all the provided files into correct subfolders. You can unzip or copy-paste.

### Step 2: Add your PDFs and `challenge1b_input.json` inside:
- `Challenge_1b/Collection 1/`
- `Challenge_1b/Collection 2/`
- `Challenge_1b/Collection 3/`

### Step 3: Then run:
```bash
docker build -t challenge1b-lite .
docker run --rm -v "${PWD}/Challenge_1b:/app/Challenge_1b" challenge1b-lite
```
